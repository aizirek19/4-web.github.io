const myHeading = document.querySelector("h1");
myHeading.textContent = "AIU - Gateway to the world ";

//alert("Header has changed");

let a = 0;
const myImg = document.querySelector("img");
const button = document.querySelector("button");

function buttonClickMe() {
    a++;
    if (a % 2 === 1) {
        console.log("Button clicked " + a + " times");
        myImg.setAttribute("src", "https://media.istockphoto.com/id/610041376/photo/beautiful-sunrise-over-the-sea.jpg?s=612x612&w=0&k=20&c=R3Tcc6HKc1ixPrBc7qXvXFCicm8jLMMlT99MfmchLNA=");
        
    } else {
        console.log("Button clicked " + a + " times");
        myImg.setAttribute("src", "https://upload.wikimedia.org/wikipedia/en/thumb/0/07/Ala-Too_International_University_Seal.png/220px-Ala-Too_International_University_Seal.png");
    }
}

function ChangeHeader() {
    const userName = prompt("Enter your name: ");
    alert( userName )
    if (userName) {
        myHeading.textContent = "Welcome, " + userName;
    }
}

myImg.addEventListener("click", buttonClickMe);
button.addEventListener("click", buttonClickMe);





